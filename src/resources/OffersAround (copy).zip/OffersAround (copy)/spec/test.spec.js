describe("testing adding function",function(){
    it("adding two numbers",function(){
        expect(1+2).toEqual(3);
    });
});